# Test some things in CheckoutableTemplates

