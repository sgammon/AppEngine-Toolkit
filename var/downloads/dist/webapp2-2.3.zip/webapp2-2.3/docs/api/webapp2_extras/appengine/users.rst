.. _api.webapp2_extras.appengine.users:

Users
=====
.. module:: webapp2_extras.appengine.users

.. autofunction:: login_required

.. autofunction:: admin_required
