.. _api.webapp2_extras.local:

Local
=====
.. module:: webapp2_extras.local

This module implements thread-local utilities.

.. autoclass:: Local
.. autoclass:: LocalProxy
